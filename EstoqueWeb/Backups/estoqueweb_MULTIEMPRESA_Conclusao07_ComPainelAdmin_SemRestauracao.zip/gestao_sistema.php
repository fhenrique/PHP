
<?php
require_once __DIR__ . '/includes/auth.php';

exigirAdministrador();

/*
|--------------------------------------------------------------------------
| Proteção CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_gestao_sistema'])) {
    $_SESSION['csrf_gestao_sistema'] = bin2hex(random_bytes(32));
}

/*
|--------------------------------------------------------------------------
| Função para proteger nomes de tabelas e colunas
|--------------------------------------------------------------------------
*/

function protegerIdentificador($nome) {
    return '`' . str_replace('`', '``', $nome) . '`';
}

/*
|--------------------------------------------------------------------------
| Função para transformar valores em SQL
|--------------------------------------------------------------------------
*/

function converterValorSQL($valor, $tipo) {

    if ($valor === null) {
        return 'NULL';
    }

    // Campos binários
    if (strpos($tipo, 'blob') !== false ||
        strpos($tipo, 'binary') !== false) {

        return '0x' . bin2hex($valor);
    }

    // Campos numéricos
    $tiposNumericos = array(
        'tinyint',
        'smallint',
        'mediumint',
        'int',
        'integer',
        'bigint',
        'decimal',
        'numeric',
        'float',
        'double',
        'real',
        'bit',
        'year'
    );

    foreach ($tiposNumericos as $tipoNumerico) {

        if (strpos($tipo, $tipoNumerico) === 0) {

            if (!is_numeric($valor)) {
                throw new Exception('Valor numérico inválido encontrado no banco.');
            }

            return (string)$valor;
        }
    }

    // Demais campos: texto, datas, horários etc.
    return "'" . str_replace(
        array("\\", "'", "\0", "\n", "\r", "\x1a"),
        array("\\\\", "\\'", "\\0", "\\n", "\\r", "\\Z"),
        (string)$valor
    ) . "'";
}


/*
|--------------------------------------------------------------------------
| Leitura segura do arquivo de backup de dados
|--------------------------------------------------------------------------
*/

function dividirValoresBackupSQL($texto) {
    $valores = array();
    $atual = '';
    $dentroAspas = false;
    $escape = false;
    $tamanho = strlen($texto);

    for ($i = 0; $i < $tamanho; $i++) {
        $caractere = $texto[$i];
        if ($escape) {
            $atual .= $caractere;
            $escape = false;
            continue;
        }
        if ($dentroAspas && $caractere === "\\") {
            $atual .= $caractere;
            $escape = true;
            continue;
        }
        if ($caractere === "'") {
            $dentroAspas = !$dentroAspas;
            $atual .= $caractere;
            continue;
        }
        if ($caractere === ',' && !$dentroAspas) {
            $valores[] = trim($atual);
            $atual = '';
            continue;
        }
        $atual .= $caractere;
    }

    if ($dentroAspas || $escape) {
        throw new Exception('Arquivo de backup inválido: texto SQL incompleto.');
    }

    if (trim($atual) !== '') {
        $valores[] = trim($atual);
    }

    return $valores;
}

function decodificarValorBackupSQL($valor) {
    $valor = trim($valor);

    if (strtoupper($valor) === 'NULL') {
        return null;
    }

    if (preg_match('/^0x([0-9a-f]*)$/i', $valor, $m)) {
        $binario = hex2bin($m[1]);
        if ($binario === false) {
            throw new Exception('Valor binário inválido no backup.');
        }
        return $binario;
    }

    if (preg_match('/^-?[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$/', $valor)) {
        return $valor;
    }

    if (strlen($valor) >= 2 && $valor[0] === "'" && substr($valor, -1) === "'") {
        $interior = substr($valor, 1, -1);
        return stripcslashes($interior);
    }

    throw new Exception('O backup contém um valor SQL não permitido.');
}

function lerBackupDadosEmpresa($caminho) {
    $conteudo = file_get_contents($caminho);
    if ($conteudo === false ||
        strpos($conteudo, '-- BACKUP DOS DADOS DO ESTOQUEWEB') !== 0) {
        throw new Exception('O arquivo selecionado não é um backup de dados válido do EstoqueWeb.');
    }

    if (!preg_match('/^-- ID da empresa:\s*([0-9]+)\s*$/m', $conteudo, $m)) {
        throw new Exception('Não foi possível identificar a empresa de origem do backup.');
    }

    $empresaBackup = (int)$m[1];
    $permitidas = array(
        'categorias', 'fornecedores', 'produtos', 'usuarios',
        'entradas_estoque', 'itens_entrada', 'movimentacoes'
    );

    $dados = array();
    foreach ($permitidas as $tabela) {
        $dados[$tabela] = array();
    }

    $linhas = preg_split('/\r\n|\r|\n/', $conteudo);

    foreach ($linhas as $linha) {
        $linha = trim($linha);

        if ($linha === '' || strpos($linha, '--') === 0 ||
            stripos($linha, 'SET FOREIGN_KEY_CHECKS') === 0) {
            continue;
        }

        if (!preg_match(
            '/^INSERT INTO `([a-zA-Z0-9_]+)`\s*\((.*?)\)\s*VALUES\s*\((.*)\);$/i',
            $linha,
            $partes
        )) {
            throw new Exception('O backup contém um comando SQL não permitido.');
        }

        $tabela = $partes[1];
        if (!in_array($tabela, $permitidas, true)) {
            throw new Exception('O backup contém uma tabela não autorizada: ' . $tabela);
        }

        preg_match_all('/`([a-zA-Z0-9_]+)`/', $partes[2], $colunasEncontradas);
        $colunas = $colunasEncontradas[1];
        $valoresBrutos = dividirValoresBackupSQL($partes[3]);

        if (count($colunas) === 0 || count($colunas) !== count($valoresBrutos)) {
            throw new Exception('O backup contém quantidade inválida de colunas ou valores.');
        }

        $registro = array();
        foreach ($colunas as $indice => $coluna) {
            if (array_key_exists($coluna, $registro)) {
                throw new Exception('O backup contém coluna duplicada.');
            }
            $registro[$coluna] = decodificarValorBackupSQL($valoresBrutos[$indice]);
        }

        if (!isset($registro['empresa_id']) ||
            (int)$registro['empresa_id'] !== $empresaBackup) {
            throw new Exception('Foi encontrado registro que não pertence à empresa informada no backup.');
        }

        $dados[$tabela][] = $registro;
    }

    return array($empresaBackup, $dados);
}


/*
|--------------------------------------------------------------------------
| Processamento das exportações
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['acao'])) {

    if (
        empty($_POST['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_gestao_sistema'],
            $_POST['csrf_token']
        )
    ) {
        http_response_code(403);
        exit('Requisição inválida. Atualize a página e tente novamente.');
    }

    try {

        /*
        |--------------------------------------------------------------------------
        | EXPORTAÇÃO 1 - ESTRUTURA
        |--------------------------------------------------------------------------
        */

        if ($_POST['acao'] === 'restaurar_dados') {

            if (empty($empresaId)) {
                throw new Exception('Nenhuma empresa está selecionada.');
            }

            if (!isset($_FILES['arquivo_backup']) ||
                $_FILES['arquivo_backup']['error'] !== UPLOAD_ERR_OK ||
                !is_uploaded_file($_FILES['arquivo_backup']['tmp_name'])) {
                throw new Exception('Selecione um arquivo SQL válido para restauração.');
            }

            if ($_FILES['arquivo_backup']['size'] > 25 * 1024 * 1024) {
                throw new Exception('O arquivo ultrapassa o limite de 25 MB.');
            }

            $nomeOriginal = isset($_FILES['arquivo_backup']['name'])
                ? $_FILES['arquivo_backup']['name'] : '';
            if (strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION)) !== 'sql') {
                throw new Exception('O arquivo de restauração deve possuir extensão .sql.');
            }

            list($empresaBackup, $dadosBackup) =
                lerBackupDadosEmpresa($_FILES['arquivo_backup']['tmp_name']);

            if ((int)$empresaBackup !== (int)$empresaId) {
                throw new Exception('O backup pertence a outra empresa. Nenhum dado foi alterado.');
            }

            $stmtEmpresa = $pdo->prepare('SELECT id FROM empresas WHERE id = ?');
            $stmtEmpresa->execute(array($empresaId));
            if (!$stmtEmpresa->fetchColumn()) {
                throw new Exception('A empresa selecionada não existe no banco atual.');
            }

            // Confere tabelas e colunas antes de iniciar qualquer exclusão.
            $tabelasRestauracao = array(
                'usuarios', 'categorias', 'fornecedores', 'produtos',
                'entradas_estoque', 'itens_entrada', 'movimentacoes'
            );

            foreach ($tabelasRestauracao as $tabela) {
                $stmtExiste = $pdo->prepare("
                    SELECT COUNT(*)
                    FROM information_schema.TABLES
                    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
                ");
                $stmtExiste->execute(array($tabela));
                if (!(int)$stmtExiste->fetchColumn()) {
                    throw new Exception('A tabela necessária não existe: ' . $tabela);
                }

                foreach ($dadosBackup[$tabela] as $registro) {
                    foreach (array_keys($registro) as $coluna) {
                        $stmtColuna = $pdo->prepare("
                            SELECT COUNT(*)
                            FROM information_schema.COLUMNS
                            WHERE TABLE_SCHEMA = DATABASE()
                              AND TABLE_NAME = ? AND COLUMN_NAME = ?
                        ");
                        $stmtColuna->execute(array($tabela, $coluna));
                        if (!(int)$stmtColuna->fetchColumn()) {
                            throw new Exception('Coluna não encontrada na estrutura atual: ' . $tabela . '.' . $coluna);
                        }
                    }
                }
            }

            // Os perfis são globais e não são restaurados; devem existir previamente.
            $perfisNecessarios = array();
            foreach ($dadosBackup['usuarios'] as $usuarioBackup) {
                if (isset($usuarioBackup['perfil_id'])) {
                    $perfisNecessarios[] = (int)$usuarioBackup['perfil_id'];
                }
            }
            $perfisNecessarios = array_unique($perfisNecessarios);

            foreach ($perfisNecessarios as $perfilId) {
                $stmtPerfil = $pdo->prepare('SELECT id FROM perfis WHERE id = ?');
                $stmtPerfil->execute(array($perfilId));
                if (!$stmtPerfil->fetchColumn()) {
                    throw new Exception('O perfil ID ' . $perfilId . ' utilizado no backup não existe no banco atual. Restauração cancelada.');
                }
            }

            // Detecta IDs que estejam ocupados por outra empresa antes de apagar qualquer dado.
            foreach ($tabelasRestauracao as $tabela) {
                foreach ($dadosBackup[$tabela] as $registro) {
                    if (!isset($registro['id'])) {
                        throw new Exception('Registro sem chave ID encontrado na tabela ' . $tabela . '.');
                    }

                    $stmtConflito = $pdo->prepare(
                        'SELECT empresa_id FROM ' . protegerIdentificador($tabela) . ' WHERE id = ?'
                    );
                    $stmtConflito->execute(array($registro['id']));
                    $empresaIdExistente = $stmtConflito->fetchColumn();

                    if ($empresaIdExistente !== false &&
                        (int)$empresaIdExistente !== (int)$empresaId) {
                        throw new Exception(
                            'Conflito de ID na tabela ' . $tabela .
                            ': o ID ' . $registro['id'] .
                            ' já pertence a outra empresa. Nenhum dado foi alterado.'
                        );
                    }
                }
            }

            $pdo->beginTransaction();

            try {
                // Exclusão em ordem inversa dos relacionamentos, sempre limitada à empresa.
                $ordemExclusao = array(
                    'movimentacoes', 'itens_entrada', 'entradas_estoque',
                    'produtos', 'categorias', 'fornecedores', 'usuarios'
                );

                foreach ($ordemExclusao as $tabela) {
                    $stmtDelete = $pdo->prepare(
                        'DELETE FROM ' . protegerIdentificador($tabela) . ' WHERE empresa_id = ?'
                    );
                    $stmtDelete->execute(array($empresaId));
                }

                // Inserção respeitando os vínculos entre os registros.
                foreach ($tabelasRestauracao as $tabela) {
                    foreach ($dadosBackup[$tabela] as $registro) {
                        $colunas = array_keys($registro);
                        $nomesSQL = array();
                        $marcadores = array();

                        foreach ($colunas as $coluna) {
                            $nomesSQL[] = protegerIdentificador($coluna);
                            $marcadores[] = '?';
                        }

                        $sqlInsert = 'INSERT INTO ' . protegerIdentificador($tabela) .
                            ' (' . implode(', ', $nomesSQL) . ') VALUES (' .
                            implode(', ', $marcadores) . ')';

                        $stmtInsert = $pdo->prepare($sqlInsert);
                        $stmtInsert->execute(array_values($registro));
                    }
                }

                $pdo->commit();

            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }

            $_SESSION['mensagem_gestao_sistema'] =
                'Restauração concluída. Somente os dados operacionais da empresa foram substituídos.';
            header('Location: gestao_sistema.php?restauracao=sucesso');
            exit;

        } elseif ($_POST['acao'] === 'exportar_estrutura') {

            $banco = $pdo->query('SELECT DATABASE()')->fetchColumn();

            if (!$banco) {
                throw new Exception('Não foi possível identificar o banco de dados.');
            }

$resultadoTabelas = $pdo->query('SHOW FULL TABLES');

$tabelasEncontradas = array();

while ($linha = $resultadoTabelas->fetch(PDO::FETCH_NUM)) {

    if (isset($linha[1]) && $linha[1] === 'BASE TABLE') {
        $tabelasEncontradas[] = $linha[0];
    }
}

/*
|--------------------------------------------------------------------------
| Ordem correta de criação das tabelas
|--------------------------------------------------------------------------
*/

$ordemCriacao = array(
    'empresas',
    'perfis',
    'categorias',
    'fornecedores',
    'usuarios',
    'produtos',
    'entradas_estoque',
    'itens_entrada',
    'movimentacoes'
);

$tabelas = array();

// Primeiro, adiciona as tabelas na ordem definida
foreach ($ordemCriacao as $nomeTabela) {

    if (in_array($nomeTabela, $tabelasEncontradas, true)) {
        $tabelas[] = $nomeTabela;
    }
}

// Depois, acrescenta eventuais tabelas adicionais
foreach ($tabelasEncontradas as $nomeTabela) {

    if (!in_array($nomeTabela, $tabelas, true)) {
        $tabelas[] = $nomeTabela;
    }
}

            if (empty($tabelas)) {
                throw new Exception('Nenhuma tabela foi encontrada.');
            }

            $conteudo = "";

            $conteudo .= "-- BACKUP DA ESTRUTURA DO ESTOQUEWEB\n";
            $conteudo .= "-- Banco: " . $banco . "\n";
            $conteudo .= "-- Data: " . date('d/m/Y H:i:s') . "\n\n";

            $conteudo .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n";
            $conteudo .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

            foreach ($tabelas as $tabela) {

                $tabelaProtegida = protegerIdentificador($tabela);

                $resultadoCreate = $pdo->query(
                    "SHOW CREATE TABLE " . $tabelaProtegida
                );

                $dadosCreate = $resultadoCreate->fetch(PDO::FETCH_NUM);

                if (!isset($dadosCreate[1])) {
                    throw new Exception(
                        'Não foi possível obter a estrutura da tabela: ' . $tabela
                    );
                }

                $conteudo .= "-- TABELA: " . $tabela . "\n";
                $conteudo .= "DROP TABLE IF EXISTS " . $tabelaProtegida . ";\n";
                $conteudo .= $dadosCreate[1] . ";\n\n";
            }

            $conteudo .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            $conteudo .= "-- FIM DO BACKUP DA ESTRUTURA\n";

            $nomeArquivo = 'estrutura_estoqueweb_' . date('Ymd_His') . '.sql';

        /*
        |--------------------------------------------------------------------------
        | EXPORTAÇÃO 2 - DADOS DA EMPRESA
        |--------------------------------------------------------------------------
        */

        } elseif ($_POST['acao'] === 'exportar_dados') {

            if (empty($empresaId)) {
                throw new Exception('Nenhuma empresa está selecionada.');
            }

            // Confirma que a empresa selecionada existe
            $stmtEmpresa = $pdo->prepare(
                "SELECT id, nome FROM empresas WHERE id = ?"
            );

            $stmtEmpresa->execute(array($empresaId));

            $empresa = $stmtEmpresa->fetch(PDO::FETCH_ASSOC);

            if (!$empresa) {
                throw new Exception('A empresa selecionada não foi encontrada.');
            }

            /*
             * Ordem de exportação:
             * respeita os relacionamentos entre as tabelas.
             */
            $tabelasExportacao = array(
                'categorias',
                'fornecedores',
                'produtos',
                'usuarios',
                'entradas_estoque',
                'itens_entrada',
                'movimentacoes'
            );

            /*
             * Mapeamento explícito das tabelas que pertencem
             * a uma empresa.
             *
             * Tabelas futuras não serão exportadas automaticamente.
             */
            $tabelasEmpresa = array(
                'categorias',
                'fornecedores',
                'produtos',
                'usuarios',
                'entradas_estoque',
                'itens_entrada',
                'movimentacoes'
            );

            // Confirma se as tabelas esperadas existem
            $tabelasBanco = $pdo->query('SHOW FULL TABLES')
                ->fetchAll(PDO::FETCH_NUM);

            $existentes = array();

            foreach ($tabelasBanco as $linha) {
                if (isset($linha[1]) && $linha[1] === 'BASE TABLE') {
                    $existentes[] = $linha[0];
                }
            }

            foreach ($tabelasExportacao as $tabela) {

                if (!in_array($tabela, $existentes, true)) {
                    throw new Exception(
                        'A tabela necessária não foi encontrada: ' . $tabela
                    );
                }
            }

            $conteudo = "";

            $conteudo .= "-- BACKUP DOS DADOS DO ESTOQUEWEB\n";
            $conteudo .= "-- Empresa: " . $empresa['nome'] . "\n";
            $conteudo .= "-- ID da empresa: " . $empresa['id'] . "\n";
            $conteudo .= "-- Conteudo: categorias, fornecedores, produtos, usuarios, entradas, itens e movimentacoes\n";
            $conteudo .= "-- Data: " . date('d/m/Y H:i:s') . "\n\n";

            $conteudo .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

            foreach ($tabelasExportacao as $tabela) {

                $tabelaProtegida = protegerIdentificador($tabela);

                /*
                 * Monta a consulta conforme a tabela.
                 */

                if (in_array($tabela, $tabelasEmpresa, true)) {

                    $sql = "SELECT * FROM " . $tabelaProtegida .
                           " WHERE empresa_id = ?";

                    $parametros = array($empresaId);

                } else {

                    // Segurança: não exporta tabelas sem regra definida.
                    continue;
                }

                $stmt = $pdo->prepare($sql);
                $stmt->execute($parametros);

                $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if (empty($registros)) {
                    $conteudo .= "-- TABELA: " . $tabela . " (sem registros)\n\n";
                    continue;
                }

                // Obtém os tipos das colunas para serialização correta
                $stmtColunas = $pdo->prepare("
                    SELECT COLUMN_NAME, DATA_TYPE
                    FROM information_schema.COLUMNS
                    WHERE TABLE_SCHEMA = DATABASE()
                    AND TABLE_NAME = ?
                    ORDER BY ORDINAL_POSITION
                ");

                $stmtColunas->execute(array($tabela));

                $tiposColunas = array();

                while ($coluna = $stmtColunas->fetch(PDO::FETCH_ASSOC)) {
                    $tiposColunas[$coluna['COLUMN_NAME']] =
                        strtolower($coluna['DATA_TYPE']);
                }

                $colunas = array_keys($registros[0]);

                $colunasSQL = array();

                foreach ($colunas as $coluna) {
                    $colunasSQL[] = protegerIdentificador($coluna);
                }

                $conteudo .= "-- TABELA: " . $tabela . "\n";

                foreach ($registros as $registro) {

                    $valoresSQL = array();

                    foreach ($colunas as $coluna) {

                        $tipo = isset($tiposColunas[$coluna])
                            ? $tiposColunas[$coluna]
                            : 'varchar';

                        $valoresSQL[] = converterValorSQL(
                            $registro[$coluna],
                            $tipo
                        );
                    }

                    $conteudo .=
                        "INSERT INTO " . $tabelaProtegida .
                        " (" . implode(', ', $colunasSQL) . ") VALUES (" .
                        implode(', ', $valoresSQL) . ");\n";
                }

                $conteudo .= "\n";
            }

            $conteudo .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            $conteudo .= "-- FIM DO BACKUP DOS DADOS\n";

            $nomeArquivo = 'dados_empresa_' . $empresaId . '_' .
                           date('Ymd_His') . '.sql';

        } else {

            throw new Exception('Ação de exportação inválida.');
        }

        /*
        |--------------------------------------------------------------------------
        | DOWNLOAD DO ARQUIVO
        |--------------------------------------------------------------------------
        */

        header('Content-Type: application/sql; charset=utf-8');

        header(
            'Content-Disposition: attachment; filename="' .
            $nomeArquivo . '"'
        );

        header('Content-Length: ' . strlen($conteudo));
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');

        echo $conteudo;
        exit;

    } catch (Exception $e) {

        error_log('Erro na Gestão do Sistema: ' . $e->getMessage());

        if (isset($_POST['acao']) && $_POST['acao'] === 'restaurar_dados') {
            $_SESSION['erro_gestao_sistema'] = $e->getMessage();
            header('Location: gestao_sistema.php?restauracao=erro');
            exit;
        }

        http_response_code(500);
        exit(
            'Não foi possível gerar o arquivo SQL. ' .
            'Verifique os registros de erro do servidor.'
        );
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">
                <i class="bi bi-gear-wide-connected"></i>
                Gestão do Sistema
            </h2>

            <p class="text-muted mb-0">
                Administração e ferramentas de segurança do EstoqueWeb.
            </p>
        </div>
    </div>

    <div class="row g-4">

        <!-- ESTRUTURA DO BANCO -->
        <div class="col-md-6">

            <div class="card shadow-sm h-100">

                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="bi bi-database-gear"></i>
                        Estrutura do Banco de Dados
                    </h5>
                </div>

                <div class="card-body">

                    <p>
                        Gera um arquivo SQL contendo a estrutura integral
                        de todas as tabelas do banco de dados.
                    </p>

                    <ul>
                        <li>Estrutura de todas as tabelas.</li>
                        <li>Campos e tipos de dados.</li>
                        <li>Chaves primárias e estrangeiras.</li>
                        <li>Índices e AUTO_INCREMENT.</li>
                    </ul>

                    <div class="alert alert-info">
                        Este arquivo contém somente estruturas.
                        Nenhum registro será exportado.
                    </div>

                    <form method="POST" action="gestao_sistema.php">

                        <input type="hidden" name="acao"
                               value="exportar_estrutura">

                        <input type="hidden" name="csrf_token"
                               value="<?php echo htmlspecialchars(
                                   $_SESSION['csrf_gestao_sistema'],
                                   ENT_QUOTES,
                                   'UTF-8'
                               ); ?>">

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-download"></i>
                            Gerar arquivo da estrutura
                        </button>

                    </form>

                </div>
            </div>

        </div>

        <!-- DADOS DA EMPRESA -->
        <div class="col-md-6">

            <div class="card shadow-sm h-100">

                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">
                        <i class="bi bi-database-down"></i>
                        Dados da Empresa
                    </h5>
                </div>

                <div class="card-body">

                    <p>
                        Gera um arquivo SQL contendo os
                        registros da empresa.
                    </p>

                    <ul>
                        <li>Categorias, fornecedores e produtos;</li>
                        <li>Usuários;</li>
                        <li>Entradas e respectivos itens;</li>
                        <li>Movimentações de estoque.</li>
                    </ul>

                    <div class="alert bg-transparent border-0 text-dark">

                    </div>

                    <form method="POST" action="gestao_sistema.php">

                        <input type="hidden" name="acao"
                               value="exportar_dados">

                        <input type="hidden" name="csrf_token"
                               value="<?php echo htmlspecialchars(
                                   $_SESSION['csrf_gestao_sistema'],
                                   ENT_QUOTES,
                                   'UTF-8'
                               ); ?>">

                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-download"></i>
                            Gerar arquivo dos dados da empresa
                        </button>

                    </form>

                </div>
            </div>

        </div>

        <!-- RESTAURACAO SOMENTE DOS DADOS OPERACIONAIS -->
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-warning">
                    <h5 class="mb-0">
                        <i class="bi bi-database-up"></i>
                        Restaurar somente os dados da empresa
                    </h5>
                </div>
                <div class="card-body">
                    <p>
                        Substitui os dados operacionais da empresa, mantendo
                        a estrutura atual do banco.
                    </p>
                    <ul>
                        <li>Categorias, fornecedores e produtos;</li>
                        <li>Usuários;</li>
                        <li>Entradas de estoque e respectivos itens;</li>
                        <li>Movimentações de estoque.</li>
                    </ul>
                    <div class="alert alert-warning">
                        Os cadastros "Empresa" e "Perfis" devem
                        ser criados manualmente.
                        A operação não poderá ser desfeita.
                    </div>

                    <?php if (!empty($_SESSION['mensagem_gestao_sistema'])): ?>
                        <div class="alert alert-success">
                            <?php
                            echo htmlspecialchars($_SESSION['mensagem_gestao_sistema'], ENT_QUOTES, 'UTF-8');
                            unset($_SESSION['mensagem_gestao_sistema']);
                            ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($_SESSION['erro_gestao_sistema'])): ?>
                        <div class="alert alert-danger">
                            <?php
                            echo htmlspecialchars($_SESSION['erro_gestao_sistema'], ENT_QUOTES, 'UTF-8');
                            unset($_SESSION['erro_gestao_sistema']);
                            ?>
                        </div>
                    <?php endif; ?>

                    <form id="formRestaurarDados" method="POST"
                          action="gestao_sistema.php" enctype="multipart/form-data">
                        <input type="hidden" name="acao" value="restaurar_dados">
                        <input type="hidden" name="csrf_token"
                               value="<?php echo htmlspecialchars($_SESSION['csrf_gestao_sistema'], ENT_QUOTES, 'UTF-8'); ?>">

                        <div class="mb-3">
                            <label for="arquivo_backup" class="form-label">
                                Arquivo SQL do backup de dados
                            </label>
                            <input type="file" class="form-control" id="arquivo_backup"
                                   name="arquivo_backup" accept=".sql" required>
                            <small class="text-muted">Tamanho máximo: 25 MB.</small>
                        </div>

                        <button type="button" class="btn btn-warning w-100"
                                id="btnAbrirConfirmacaoRestauracao">
                            <i class="bi bi-arrow-counterclockwise"></i>
                            Restaurar somente dados mantendo a estrutura atual do banco
                        </button>
                    </form>
                </div>
            </div>
        </div>

    </div>

</div>

<!-- PRIMEIRA CONFIRMACAO -->
<div class="modal fade" id="modalConfirmacaoRestauracao" tabindex="-1"
     aria-labelledby="tituloConfirmacaoRestauracao" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="tituloConfirmacaoRestauracao">
                    Confirmar restauração
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                O arquivo <strong id="nomeArquivoRestauracao"></strong> será utilizado
                para substituir os dados operacionais da empresa selecionada.
                Deseja continuar?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Cancelar
                </button>
                <button type="button" class="btn btn-warning" id="btnSegundaConfirmacao">
                    Continuar
                </button>
            </div>
        </div>
    </div>
</div>

<!-- SEGUNDA CONFIRMACAO -->
<div class="modal fade" id="modalConfirmacaoFinalRestauracao" tabindex="-1"
     aria-labelledby="tituloConfirmacaoFinalRestauracao" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="tituloConfirmacaoFinalRestauracao">
                    Confirmação final
                </h5>
                <button type="button" class="btn-close btn-close-white"
                        data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <strong>Atenção!</strong> Os dados atuais de categorias, fornecedores,
                produtos, usuários, entradas, itens e movimentações desta empresa
                serão excluídos e substituídos pelos dados do backup.
                <br><br>
                A estrutura do banco e os dados das outras empresas serão preservados.
                Esta operação não pode ser desfeita. Confirma a restauração?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Não, cancelar
                </button>
                <button type="button" class="btn btn-danger" id="btnExecutarRestauracao">
                    Sim, restaurar agora
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var formulario = document.getElementById('formRestaurarDados');
    var arquivo = document.getElementById('arquivo_backup');
    var botaoAbrir = document.getElementById('btnAbrirConfirmacaoRestauracao');
    var nomeArquivo = document.getElementById('nomeArquivoRestauracao');
    var modalInicialEl = document.getElementById('modalConfirmacaoRestauracao');
    var modalFinalEl = document.getElementById('modalConfirmacaoFinalRestauracao');

    if (!formulario || !window.bootstrap) {
        return;
    }

    var modalInicial = new bootstrap.Modal(modalInicialEl);
    var modalFinal = new bootstrap.Modal(modalFinalEl);

    botaoAbrir.addEventListener('click', function () {
        if (!arquivo.files || !arquivo.files.length) {
            arquivo.reportValidity();
            return;
        }

        nomeArquivo.textContent = arquivo.files[0].name;
        modalInicial.show();
    });

    document.getElementById('btnSegundaConfirmacao').addEventListener('click', function () {
        modalInicial.hide();
        modalFinal.show();
    });

    document.getElementById('btnExecutarRestauracao').addEventListener('click', function () {
        var botao = this;
        botao.disabled = true;
        botao.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Restaurando...';
        formulario.submit();
    });
});
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>