
<?php
require_once __DIR__ . '/includes/auth.php';

exigirAdministrador();

/*
|--------------------------------------------------------------------------
| Proteção CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_gestao_sistema'])) {
    $_SESSION['csrf_gestao_sistema'] = bin2hex(random_bytes(32));
}

/*
|--------------------------------------------------------------------------
| Função para proteger nomes de tabelas e colunas
|--------------------------------------------------------------------------
*/

function protegerIdentificador($nome) {
    return '`' . str_replace('`', '``', $nome) . '`';
}

/*
|--------------------------------------------------------------------------
| Função para transformar valores em SQL
|--------------------------------------------------------------------------
*/

function converterValorSQL($valor, $tipo) {

    if ($valor === null) {
        return 'NULL';
    }

    // Campos binários
    if (strpos($tipo, 'blob') !== false ||
        strpos($tipo, 'binary') !== false) {

        return '0x' . bin2hex($valor);
    }

    // Campos numéricos
    $tiposNumericos = array(
        'tinyint',
        'smallint',
        'mediumint',
        'int',
        'integer',
        'bigint',
        'decimal',
        'numeric',
        'float',
        'double',
        'real',
        'bit',
        'year'
    );

    foreach ($tiposNumericos as $tipoNumerico) {

        if (strpos($tipo, $tipoNumerico) === 0) {

            if (!is_numeric($valor)) {
                throw new Exception('Valor numérico inválido encontrado no banco.');
            }

            return (string)$valor;
        }
    }

    // Demais campos: texto, datas, horários etc.
    return "'" . str_replace(
        array("\\", "'", "\0", "\n", "\r", "\x1a"),
        array("\\\\", "\\'", "\\0", "\\n", "\\r", "\\Z"),
        (string)$valor
    ) . "'";
}

/*
|--------------------------------------------------------------------------
| Processamento das exportações
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['acao'])) {

    if (
        empty($_POST['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_gestao_sistema'],
            $_POST['csrf_token']
        )
    ) {
        http_response_code(403);
        exit('Requisição inválida. Atualize a página e tente novamente.');
    }

    try {

        /*
        |--------------------------------------------------------------------------
        | EXPORTAÇÃO 1 - ESTRUTURA
        |--------------------------------------------------------------------------
        */

        if ($_POST['acao'] === 'exportar_estrutura') {

            $banco = $pdo->query('SELECT DATABASE()')->fetchColumn();

            if (!$banco) {
                throw new Exception('Não foi possível identificar o banco de dados.');
            }

$resultadoTabelas = $pdo->query('SHOW FULL TABLES');

$tabelasEncontradas = array();

while ($linha = $resultadoTabelas->fetch(PDO::FETCH_NUM)) {

    if (isset($linha[1]) && $linha[1] === 'BASE TABLE') {
        $tabelasEncontradas[] = $linha[0];
    }
}

/*
|--------------------------------------------------------------------------
| Ordem correta de criação das tabelas
|--------------------------------------------------------------------------
*/

$ordemCriacao = array(
    'empresas',
    'perfis',
    'categorias',
    'fornecedores',
    'usuarios',
    'produtos',
    'entradas_estoque',
    'itens_entrada',
    'movimentacoes'
);

$tabelas = array();

// Primeiro, adiciona as tabelas na ordem definida
foreach ($ordemCriacao as $nomeTabela) {

    if (in_array($nomeTabela, $tabelasEncontradas, true)) {
        $tabelas[] = $nomeTabela;
    }
}

// Depois, acrescenta eventuais tabelas adicionais
foreach ($tabelasEncontradas as $nomeTabela) {

    if (!in_array($nomeTabela, $tabelas, true)) {
        $tabelas[] = $nomeTabela;
    }
}

            if (empty($tabelas)) {
                throw new Exception('Nenhuma tabela foi encontrada.');
            }

            $conteudo = "";

            $conteudo .= "-- BACKUP DA ESTRUTURA DO ESTOQUEWEB\n";
            $conteudo .= "-- Banco: " . $banco . "\n";
            $conteudo .= "-- Data: " . date('d/m/Y H:i:s') . "\n\n";

            $conteudo .= "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n";
            $conteudo .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

            foreach ($tabelas as $tabela) {

                $tabelaProtegida = protegerIdentificador($tabela);

                $resultadoCreate = $pdo->query(
                    "SHOW CREATE TABLE " . $tabelaProtegida
                );

                $dadosCreate = $resultadoCreate->fetch(PDO::FETCH_NUM);

                if (!isset($dadosCreate[1])) {
                    throw new Exception(
                        'Não foi possível obter a estrutura da tabela: ' . $tabela
                    );
                }

                $conteudo .= "-- TABELA: " . $tabela . "\n";
                $conteudo .= "DROP TABLE IF EXISTS " . $tabelaProtegida . ";\n";
                $conteudo .= $dadosCreate[1] . ";\n\n";
            }

            $conteudo .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            $conteudo .= "-- FIM DO BACKUP DA ESTRUTURA\n";

            $nomeArquivo = 'estrutura_estoqueweb_' . date('Ymd_His') . '.sql';

        /*
        |--------------------------------------------------------------------------
        | EXPORTAÇÃO 2 - DADOS DA EMPRESA
        |--------------------------------------------------------------------------
        */

        } elseif ($_POST['acao'] === 'exportar_dados') {

            if (empty($empresaId)) {
                throw new Exception('Nenhuma empresa está selecionada.');
            }

            // Confirma que a empresa selecionada existe
            $stmtEmpresa = $pdo->prepare(
                "SELECT id, nome FROM empresas WHERE id = ?"
            );

            $stmtEmpresa->execute(array($empresaId));

            $empresa = $stmtEmpresa->fetch(PDO::FETCH_ASSOC);

            if (!$empresa) {
                throw new Exception('A empresa selecionada não foi encontrada.');
            }

            /*
             * Ordem de exportação:
             * respeita os relacionamentos entre as tabelas.
             */
            $tabelasExportacao = array(
                'empresas',
                'perfis',
                'usuarios',
                'categorias',
                'fornecedores',
                'produtos',
                'entradas_estoque',
                'itens_entrada',
                'movimentacoes'
            );

            /*
             * Mapeamento explícito das tabelas que pertencem
             * a uma empresa.
             *
             * Tabelas futuras não serão exportadas automaticamente.
             */
            $tabelasEmpresa = array(
                'categorias',
                'fornecedores',
                'produtos',
                'usuarios',
                'entradas_estoque',
                'itens_entrada',
                'movimentacoes'
            );

            // Confirma se as tabelas esperadas existem
            $tabelasBanco = $pdo->query('SHOW FULL TABLES')
                ->fetchAll(PDO::FETCH_NUM);

            $existentes = array();

            foreach ($tabelasBanco as $linha) {
                if (isset($linha[1]) && $linha[1] === 'BASE TABLE') {
                    $existentes[] = $linha[0];
                }
            }

            foreach ($tabelasExportacao as $tabela) {

                if (!in_array($tabela, $existentes, true)) {
                    throw new Exception(
                        'A tabela necessária não foi encontrada: ' . $tabela
                    );
                }
            }

            $conteudo = "";

            $conteudo .= "-- BACKUP DOS DADOS DO ESTOQUEWEB\n";
            $conteudo .= "-- Empresa: " . $empresa['nome'] . "\n";
            $conteudo .= "-- ID da empresa: " . $empresa['id'] . "\n";
            $conteudo .= "-- Data: " . date('d/m/Y H:i:s') . "\n\n";

            $conteudo .= "SET FOREIGN_KEY_CHECKS = 0;\n\n";

            foreach ($tabelasExportacao as $tabela) {

                $tabelaProtegida = protegerIdentificador($tabela);

                /*
                 * Monta a consulta conforme a tabela.
                 */

                if ($tabela === 'empresas') {

                    $sql = "SELECT * FROM " . $tabelaProtegida .
                           " WHERE id = ?";

                    $parametros = array($empresaId);

                } elseif ($tabela === 'perfis') {

                    $sql = "
                        SELECT *
                        FROM " . $tabelaProtegida . "
                        WHERE id IN (
                            SELECT DISTINCT perfil_id
                            FROM usuarios
                            WHERE empresa_id = ?
                        )
                    ";

                    $parametros = array($empresaId);

                } elseif (in_array($tabela, $tabelasEmpresa, true)) {

                    $sql = "SELECT * FROM " . $tabelaProtegida .
                           " WHERE empresa_id = ?";

                    $parametros = array($empresaId);

                } else {

                    // Segurança: não exporta tabelas sem regra definida.
                    continue;
                }

                $stmt = $pdo->prepare($sql);
                $stmt->execute($parametros);

                $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if (empty($registros)) {
                    $conteudo .= "-- TABELA: " . $tabela . " (sem registros)\n\n";
                    continue;
                }

                // Obtém os tipos das colunas para serialização correta
                $stmtColunas = $pdo->prepare("
                    SELECT COLUMN_NAME, DATA_TYPE
                    FROM information_schema.COLUMNS
                    WHERE TABLE_SCHEMA = DATABASE()
                    AND TABLE_NAME = ?
                    ORDER BY ORDINAL_POSITION
                ");

                $stmtColunas->execute(array($tabela));

                $tiposColunas = array();

                while ($coluna = $stmtColunas->fetch(PDO::FETCH_ASSOC)) {
                    $tiposColunas[$coluna['COLUMN_NAME']] =
                        strtolower($coluna['DATA_TYPE']);
                }

                $colunas = array_keys($registros[0]);

                $colunasSQL = array();

                foreach ($colunas as $coluna) {
                    $colunasSQL[] = protegerIdentificador($coluna);
                }

                $conteudo .= "-- TABELA: " . $tabela . "\n";

                foreach ($registros as $registro) {

                    $valoresSQL = array();

                    foreach ($colunas as $coluna) {

                        $tipo = isset($tiposColunas[$coluna])
                            ? $tiposColunas[$coluna]
                            : 'varchar';

                        $valoresSQL[] = converterValorSQL(
                            $registro[$coluna],
                            $tipo
                        );
                    }

                    $conteudo .=
                        "INSERT INTO " . $tabelaProtegida .
                        " (" . implode(', ', $colunasSQL) . ") VALUES (" .
                        implode(', ', $valoresSQL) . ");\n";
                }

                $conteudo .= "\n";
            }

            $conteudo .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            $conteudo .= "-- FIM DO BACKUP DOS DADOS\n";

            $nomeArquivo = 'dados_empresa_' . $empresaId . '_' .
                           date('Ymd_His') . '.sql';

        } else {

            throw new Exception('Ação de exportação inválida.');
        }

        /*
        |--------------------------------------------------------------------------
        | DOWNLOAD DO ARQUIVO
        |--------------------------------------------------------------------------
        */

        header('Content-Type: application/sql; charset=utf-8');

        header(
            'Content-Disposition: attachment; filename="' .
            $nomeArquivo . '"'
        );

        header('Content-Length: ' . strlen($conteudo));
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');

        echo $conteudo;
        exit;

    } catch (Exception $e) {

        error_log(
            'Erro na Gestão do Sistema: ' . $e->getMessage()
        );

        http_response_code(500);

        exit(
            'Não foi possível gerar o arquivo SQL. ' .
            'Verifique os registros de erro do servidor.'
        );
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">
                <i class="bi bi-gear-wide-connected"></i>
                Gestão do Sistema
            </h2>

            <p class="text-muted mb-0">
                Administração e ferramentas de segurança do EstoqueWeb.
            </p>
        </div>
    </div>

    <div class="row g-4">

        <!-- ESTRUTURA DO BANCO -->
        <div class="col-md-6">

            <div class="card shadow-sm h-100">

                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="bi bi-database-gear"></i>
                        Estrutura do Banco de Dados
                    </h5>
                </div>

                <div class="card-body">

                    <p>
                        Gera um arquivo SQL contendo a estrutura integral
                        de todas as tabelas do banco de dados.
                    </p>

                    <ul>
                        <li>Estrutura de todas as tabelas.</li>
                        <li>Campos e tipos de dados.</li>
                        <li>Chaves primárias e estrangeiras.</li>
                        <li>Índices e AUTO_INCREMENT.</li>
                    </ul>

                    <div class="alert alert-info">
                        Este arquivo contém somente estruturas.
                        Nenhum registro será exportado.
                    </div>

                    <form method="POST" action="gestao_sistema.php">

                        <input type="hidden" name="acao"
                               value="exportar_estrutura">

                        <input type="hidden" name="csrf_token"
                               value="<?php echo htmlspecialchars(
                                   $_SESSION['csrf_gestao_sistema'],
                                   ENT_QUOTES,
                                   'UTF-8'
                               ); ?>">

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-download"></i>
                            Gerar arquivo da estrutura
                        </button>

                    </form>

                </div>
            </div>

        </div>

        <!-- DADOS DA EMPRESA -->
        <div class="col-md-6">

            <div class="card shadow-sm h-100">

                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">
                        <i class="bi bi-database-down"></i>
                        Dados da Empresa
                    </h5>
                </div>

                <div class="card-body">

                    <p>
                        Gera um arquivo SQL contendo os
                        registros da empresa.
                    </p>

                    <ul>
                        <li>Dados da empresa;</li>
                        <li>Categorias, fornecedores e produtos;</li>
                        <li>Usuários;</li>
                        <li>Entradas e respectivos itens;</li>
                        <li>Movimentações de estoque;</li>
                        <li>Perfis utilizados pelos usuários da empresa.</li>
                    </ul>

                    <div class="alert bg-transparent border-0 text-dark">
                        ㅤ
                            
                    </div>

                    <form method="POST" action="gestao_sistema.php">

                        <input type="hidden" name="acao"
                               value="exportar_dados">

                        <input type="hidden" name="csrf_token"
                               value="<?php echo htmlspecialchars(
                                   $_SESSION['csrf_gestao_sistema'],
                                   ENT_QUOTES,
                                   'UTF-8'
                               ); ?>">

                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-download"></i>
                            Gerar arquivo dos dados da empresa
                        </button>

                    </form>

                </div>
            </div>

        </div>

    </div>

</div>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
